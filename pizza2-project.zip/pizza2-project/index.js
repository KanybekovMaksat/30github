document.getElementById('menu').addEventListener('click', function(){
    document.getElementById('mobile-menu').classList.toggle("hidden")
})